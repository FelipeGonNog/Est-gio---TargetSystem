package resposta4;

public class Logica {
	 //Descubra a lógica e complete o próximo elemento:
		 //a) 1, 3, 5, 7, ___
		 //b) 2, 4, 8, 16, 32, 64, ____
		 //c) 0, 1, 4, 9, 16, 25, 36, ____
		 //d) 4, 16, 36, 64, ____
		 //e) 1, 1, 2, 3, 5, 8, ____
		 //f) 2,10, 12, 16, 17, 18, 19, ____

//Vamos analisar cada sequência e descobrir a lógica para completar o próximo elemento:

//a) 1, 3, 5, 7, ___ A sequência é formada por números ímpares consecutivos. O próximo elemento seria o próximo número ímpar, que é 9.

//b) 2, 4, 8, 16, 32, 64, ____ A sequência é formada por potências de 2. O próximo elemento seria a próxima potência de 2, que é 128.

//c) 0, 1, 4, 9, 16, 25, 36, ____ A sequência é formada por quadrados perfeitos. O próximo elemento seria o próximo quadrado perfeito, que é 49.

//d) 4, 16, 36, 64, ____ A sequência é formada por quadrados perfeitos de números pares. O próximo elemento seria o próximo quadrado perfeito de um número par, que é 100.

//e) 1, 1, 2, 3, 5, 8, ____ A sequência é a famosa sequência de Fibonacci, onde cada elemento é a soma dos dois elementos anteriores. O próximo elemento seria a soma dos dois elementos anteriores, que é 13.

//f) 2, 10, 12, 16, 17, 18, 19, ____ A sequência não parece ter uma lógica clara, mas se analisarmos os elementos, podemos notar que a sequência está aumentando em 1 ou 2 unidades a cada vez. Se continuarmos essa tendência, o próximo elemento seria 20.

//Portanto, as respostas são:

//a) 9 b) 128 c) 49 d) 100 e) 13 f) 20
}
