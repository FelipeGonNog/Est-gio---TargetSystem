package estagioTargetResposta1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Fibonacci {
	
	public static void main(String[] args) {
		
        @SuppressWarnings("resource")
        
		Scanner scanner = new Scanner(System.in);
        System.out.print("Informe um número: ");
        //Usuario entra com numero
        int n = scanner.nextInt();

        List<Integer> sequence = fibonacci(n);
        //Sequencia guardada no List
        if (sequence.contains(n)) {
            System.out.println("O número " + n + " pertence à sequência de Fibonacci.");
        } else {
            System.out.println("O número " + n + " não pertence à sequência de Fibonacci.");
        }
    }//Se o numero esta na sequencia a mensagem surge,indicando que não é um numero na tabela fibonnaci
             
    public static List<Integer> fibonacci(int n) {
        List<Integer> sequence = new ArrayList <>();
        sequence.add(0);
        sequence.add(1);
        while (sequence.get(sequence.size() - 1) < n) {
            sequence.add(sequence.get(sequence.size() - 1) + sequence.get(sequence.size() - 2));
        }
        return sequence;
    }

}
