package resposta2;

import java.util.Scanner;

public class ContadorLetras {
	
	public static void main(String[] args) {
		
        @SuppressWarnings("resource")
        
		Scanner scanner = new Scanner(System.in);
        System.out.print("Informe uma string: ");
        String input = scanner.nextLine();

        int count = countLetter(input, 'a');
        //Metodo para contar a letra 'a'
        if (count > 0) {
            System.out.println("A letra 'a' ocorre " + count + " vezes na string.");
        } else {
            System.out.println("A letra 'a' não ocorre na string.");
        }
    }

    public static int countLetter(String str, char letter) {
        int count = 0;
        for (char c : str.toLowerCase().toCharArray())
        //metodo para deixar letra minuscula
        	{
            if (c == letter || c == Character.toUpperCase(letter)) {
                count++;
                //metodo para deixar letra maiuscula
            }
        }
        return count;
    }
}

