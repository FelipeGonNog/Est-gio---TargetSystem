package resposta5;

public class SalaLampada {
 //Fiz um algoritimo de como resolver etapa a etapa
//	Passo 1:

	//	Ligue o interruptor 1 por 5 minutos. Desligue o interruptor 1. Ligue o interruptor 2. Vá até a sala das lâmpadas e observe as lâmpadas.

	//	Passo 2:

	//	Volte para a sala dos interruptores e desligue o interruptor 2. Ligue o interruptor 3. Vá até a sala das lâmpadas novamente e observe as lâmpadas.

	//	Análise:

	//	No Passo 1, você ligou o interruptor 1 por 5 minutos, o que significa que a lâmpada correspondente estará quente (ou ao menos mais quente que as outras). Em seguida, você desligou o interruptor 1 e ligou o interruptor 2. Isso significa que a lâmpada correspondente ao interruptor 2 estará acesa.

	//	Ao ir até a sala das lâmpadas, você verá três situações possíveis:

	//	Uma lâmpada está acesa e quente (interruptor 1).
	//	Uma lâmpada está acesa e fria (interruptor 2).
	//	Uma lâmpada está apagada e quente (interruptor 3).
	//	No Passo 2, você desligou o interruptor 2 e ligou o interruptor 3. Isso significa que a lâmpada correspondente ao interruptor 3 estará acesa.

	//	Ao ir até a sala das lâmpadas novamente, você verá que:

	//	A lâmpada que estava acesa e quente agora está apagada (interruptor 1).
	//	A lâmpada que estava acesa e fria agora está apagada (interruptor 2).
	//	A lâmpada que estava apagada e quente agora está acesa (interruptor 3).
	//	Com essas informações, você pode determinar qual interruptor controla qual lâmpada.

	//	Resposta:

	//	Interruptor 1: lâmpada quente no Passo 1.
	//	Interruptor 2: lâmpada acesa e fria no Passo 1.
		//Interruptor 3: lâmpada apagada e quente no Passo 1, e acesa no Passo 2.
}
